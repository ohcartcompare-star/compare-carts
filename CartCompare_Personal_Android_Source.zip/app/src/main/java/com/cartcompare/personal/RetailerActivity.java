package com.cartcompare.personal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public class RetailerActivity extends Activity {
    private WebView webView;
    private String store, itemId, itemName;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = getIntent().getStringExtra("store");
        itemId = getIntent().getStringExtra("itemId");
        itemName = getIntent().getStringExtra("itemName");
        String url = getIntent().getStringExtra("url");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(10,8,10,8);
        Button back = new Button(this); back.setText("←");
        TextView title = new TextView(this);
        title.setText(store + " · " + itemName);
        title.setTextSize(16); title.setPadding(12,0,12,0); title.setSingleLine(true);
        Button capture = new Button(this); capture.setText("Save price");
        bar.addView(back, new LinearLayout.LayoutParams(60, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(capture);
        root.addView(bar);

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(url);

        back.setOnClickListener(v -> { if(webView.canGoBack()) webView.goBack(); else finish(); });
        capture.setOnClickListener(v -> showCaptureDialog());
    }

    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setPadding(12,8,12,8); return e;
    }

    private void showCaptureDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,8,28,0);
        EditText brand=field("Brand (example: Great Value)");
        EditText product=field("Product / description");
        EditText size=field("Package size (example: 12 ct)");
        EditText price=field("Price (example: 2.49)");
        price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText note=field("Sale / member note (optional)");
        box.addView(brand);box.addView(product);box.addView(size);box.addView(price);box.addView(note);

        new AlertDialog.Builder(this)
            .setTitle("Save " + store + " price")
            .setMessage("Enter exactly what you see. CartCompare does not read or store your retailer password.")
            .setView(box).setNegativeButton("Cancel", null)
            .setPositiveButton("Save", (d,w) -> {
                try {
                    JSONObject q=new JSONObject();
                    q.put("itemId", itemId); q.put("itemName", itemName); q.put("store", store);
                    q.put("brand", brand.getText().toString().trim());
                    q.put("product", product.getText().toString().trim());
                    q.put("size", size.getText().toString().trim());
                    q.put("price", Double.parseDouble(price.getText().toString().trim()));
                    q.put("note", note.getText().toString().trim());
                    q.put("pageUrl", webView.getUrl()==null?"":webView.getUrl());
                    q.put("capturedAt", System.currentTimeMillis());
                    Intent result=new Intent(); result.putExtra("quoteJson", q.toString());
                    setResult(RESULT_OK,result); finish();
                } catch(Exception ex) {
                    new AlertDialog.Builder(this).setTitle("Price needed")
                        .setMessage("Enter a valid numeric price.").setPositiveButton("OK",null).show();
                }
            }).show();
    }

    @Override public void onBackPressed() {
        if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
